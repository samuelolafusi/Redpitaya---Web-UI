NCE - numerical computation environment

Sample programs for lcr meter and bode analyzer

Matlab requires a special plugin "plink" that enables comunication with ssh 

more info here: http://redpitaya.readthedocs.io/en/latest/search.html?q=Signal+generator+Matlab&check_keywords=yes&area=default#
