A special version of the application for working with separate triggers.
