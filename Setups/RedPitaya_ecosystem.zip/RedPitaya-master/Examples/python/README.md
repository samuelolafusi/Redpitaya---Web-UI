Python applications should be executed with the device IP address in the command line.
```bash
$ ./
```

This example is written and completely supported by Python 3.5
