# Building 
To build the example, run the command in the tcl console. 
```tcl
cd "example path"
source make_project.tcl
```

Be careful on windows, because of the limitation of the path length, problems may arise when creating and generating a project.